import math
#import re
import json
import heapq
#from scipy.sparse import lil_matrix
from numpy import *
#from bisect import insort
from collections import defaultdict
from collections import OrderedDict

n_users = 0

"""user_names is a dictionary of user_id -> screen_name"""
user_names = OrderedDict()

"""user_names is a dictionary of user_id -> index_number"""
user_numbers = OrderedDict()

"""rev_user_numbers is a dictionary of index_number -> """
rev_user_numbers = OrderedDict()

"""heap to calculate the top 50 users"""
rank_heap = defaultdict(float)

incoming_links = defaultdict(set)
outgoing_links = defaultdict(set)

tele = 0.1
precision = 0.0001


"""tokenize a tweet and convert to lower case"""
def tokenize(text):
  tok = re.split(r'\W+', text, flags=re.UNICODE)
  lower_tok = []
  for t in tok:
    if(t is None or t == ''):
      continue
    lower_tok.append(t.lower())
  return lower_tok


def read_file(filename):
  global n_tweets
  f = open(filename, 'r')
  lines = f.readlines()
  f.close()
  n_tweets = len(lines)
  return lines


"""method that returns the user mentions as a dict"""
def get_users_mentioned(json_obj):
  mentions = json_obj['entities']['user_mentions']
  user_id = json_obj['user']['id']
  mentioned_users = {}
  for m in mentions:
    u = m['id']
    if(u == user_id): #self-link
      continue
    mentioned_users[u] = m['screen_name']
  #print 'The user {0} mentions {1}'.format(user_id, mentioned_users)
  return mentioned_users


def parse_json(json_obj, tweet_ctr):
  u = json_obj['user']
  user_id = u['id']
  screen_name = u['screen_name']
  #add_user(user_id, screen_name)
  #user_internal_id = user_names[user_id][0]
  mentioned_users = get_users_mentioned(json_obj)
  
  if(len(mentioned_users) > 0):
    add_user(user_id, screen_name)

  for m in mentioned_users.keys():
    add_user(m, mentioned_users[m])  
    
    outgoing_links[user_id].add(m)
    if(user_id in incoming_links):
      pass
    else:
      incoming_links[user_id] = set()

    incoming_links[m].add(user_id)
    if(m in outgoing_links):
      pass
    else:
      outgoing_links[m] = set()
  return


"""method adds and creates a logical id for the user and adds it"""
def add_user(user_id, screen_name):
  global n_users
  #users.add(user_id) #users is a set so duplicates are taken care of
  if(user_id in user_names):
    pass
  else:
    user_names[user_id] = screen_name
    user_numbers[user_id] = n_users
    rev_user_numbers[n_users] = user_id
    n_users += 1
  return


def rank_users():
  n = n_users
  page_rank_old = [1]*n
  page_rank_new = [0]*n
  user_ids = user_names.keys()
  #print
  print n
  print len(user_ids)
  #print 'Start------'
  #print 'Old pr: '
  #print page_rank_old
  #print 'New pr: '
  #print page_rank_new
  #print
  ctr = 0
  while True:
    #print
    print 'Iteration {0}'.format(ctr)
    to_break = True
    for i in xrange(0, n):
      u = user_ids[i]
      i_links = incoming_links[u]
      if(len(i_links) == 0):
        page_rank_new[i] = tele
      else:
        x = 0.0
        for inc in i_links:
          idx = user_numbers[inc]
          y = len(outgoing_links[inc])
          x += page_rank_old[idx]/y
        x = tele + ((1-tele)*x)
        page_rank_new[i] = x
      if(math.fabs(page_rank_new[i]-page_rank_old[i]) > precision):
        to_break = False
    if(to_break == True):
      break
    #temp = page_rank_new - page_rank_old
    #print 'Old pr: '
    #print page_rank_old
    #print 'New pr: '
    #print page_rank_new
    #print 'Diff'
    #print temp
    #if(all(abs(temp) <= precision)):
    #  break
    #if(ctr == 10):
      #break
    page_rank_old[:] = page_rank_new
    ctr += 1
  
  #after computing page ranks, we need to find top 50
  for i in range(0, len(page_rank_new)):
    rank_heap[rev_user_numbers[i]] = page_rank_new[i]
  result = heapq.nlargest(50, rank_heap, key=rank_heap.get)
  print_results(result)
  return
    
"""
def rank_users():
  n = n_users
  page_rank_old = empty(n)
  page_rank_old[:] = 1
  page_rank_new = empty(n)
  page_rank_new[:] = 0
  user_ids = user_names.keys()
  #print
  print n
  print len(user_ids)
  #print 'Start------'
  #print 'Old pr: '
  #print page_rank_old
  #print 'New pr: '
  #print page_rank_new
  #print
  ctr = 0
  while True:
    #print
    print 'Iteration {0}'.format(ctr)
    to_break = True
    for i in xrange(0, n):
      u = user_ids[i]
      i_links = incoming_links[u]
      if(len(i_links) == 0):
        page_rank_new[i] = tele
      else:
        x = 0.0
        for inc in i_links:
          idx = user_numbers[inc]
          y = len(outgoing_links[inc])
          x += page_rank_old[idx]/y
        x = tele + ((1-tele)*x)
        page_rank_new[i] = x
      if(math.fabs(page_rank_new[i]-page_rank_old[i]) > precision):
        to_break = False
    if(to_break == True):
      break
    #temp = page_rank_new - page_rank_old
    #print 'Old pr: '
    #print page_rank_old
    #print 'New pr: '
    #print page_rank_new
    #print 'Diff'
    #print temp
    #if(all(abs(temp) <= precision)):
    #  break
    #if(ctr == 10):
      #break
    page_rank_old[:] = page_rank_new
    #page_rank_old = 1*page_rank_new
    #numpy.copyto(page_rank_old, page_rank_new)
    #for i in xrange(0, n):
      #page_rank_old[i] = page_rank_new[i]
    #page_rank_old = page_rank_new.copy()
    ctr += 1
    #break
  
  #after computing page ranks, we need to find top 50
  for i in range(0, len(page_rank_new)):
    rank_heap[rev_user_numbers[i]] = page_rank_new[i]
  result = heapq.nlargest(50, rank_heap, key=rank_heap.get)
  print_results(result)
  return
"""


def parse(filename):
  lines = read_file(filename)
  #f = open(filename, 'r')
  #lines = f.readlines()
  #f.close()
  tweet_ctr = 1
  for line in lines:
    data = json.loads(line)
    #parse_json(line, tweet_ctr)
    parse_json(data, tweet_ctr)
    tweet_ctr += 1
  #once the json is parsed, we need to run over the idf dict once more
  return


def process_tweets(filename):
  parse(filename)
  #print_verbose()
  return


def print_results(results):
  print
  print 'Results===='
  for r in results:
    print '{0}: {1}'.format(r, user_names[r])
  return


def print_verbose():
  print 
  print 'No of tweets: {0}, no of users: {1}'.format(n_tweets, n_users)
  print 
  print 'Users total {0} ===='.format(n_users)
  for user in user_names.keys():
    print '{0}: {1}'.format(user, user_numbers[user])
  print
  #print 'User names===='
  #print len(user_names)
  #for i in sorted(user_names.keys()):
  #  print '{0}: {1} {2}'.format(i, user_names[i])
  #print
  o_links = outgoing_links.keys()
  print 'Outgoing links total {0}===='.format(len(o_links))
  for o in sorted(o_links):
    print '{0}: {1}'.format(o, outgoing_links[o])
  print
  i_links = incoming_links.keys()
  print 'Incoming links total {0}===='.format(len(i_links))
  for i in sorted(i_links):
    print '{0}: {1}'.format(i, incoming_links[i])
  return


def print_concise():
  return   


def main():
  #signal.signal(signal.SIGINT, signal_handler)
  prompt = '>>'
  #n = len(sys.argv)
  #if(n != 2):
  #  print 'usage: python vector_space.py <input_json_file>'
  #  sys.exit(1)
  #dir_name = str(sys.argv[1])
  #filename  = 'b.json'
  filename = 'mars_tweets_medium.json'
  process_tweets(filename)
  rank_users()
  """while(True):
    print prompt,
    query = raw_input()
    if(query == ''):
      continue
    process_query(query)
    print"""
  return

if __name__ == '__main__':
  main()
