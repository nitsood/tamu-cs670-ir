import math
import re
import json
from bisect import insort
from collections import defaultdict
from collections import OrderedDict

def no_use():
  """one liner used only for defaultdict's declaration.
  Could have used lambda but lambda doesn't pickle"""
  return defaultdict(float)

tf = defaultdict(no_use)
idf = defaultdict(float)
tweets = OrderedDict()

"""tokenize a tweet and convert to lower case"""
def tokenize(text):
  tok = re.split(r'\W+', text, flags=re.UNICODE)
  lower_tok = []
  for t in tok:
    if(t is None or t == ''):
      continue
    lower_tok.append(t.lower())
  return lower_tok

def read_file(filename):
  f = open(filename, 'r')
  lines = f.readlines()
  f.close()
  return lines

"""method that calculates tf dictionary"""
def parse_json(json_obj, tweet_ctr):
  s = json_obj['text']
  tweets[tweet_ctr] = s
  tokens = tokenize(s)
  for token in tokens:
    tf[tweet_ctr][token] += 1
  unique_tokens = set(tokens)
  #make the tokens unique to do idf calc
  for token in unique_tokens:
    idf[token] += 1
  terms = tf[tweet_ctr].keys()
  #calculate log base2 values
  for k in terms:
    tf[tweet_ctr][k] = 1+math.log(tf[tweet_ctr][k], 2)
  return

"""method that calculates tf and idf dictionaries"""
def parse(filename):
  lines = read_file(filename)
  #f = open(filename, 'r')
  #lines = f.readlines()
  #f.close()
  tweet_ctr = 1
  for line in lines:
    data = json.loads(line)
    #parse_json(line, tweet_ctr)
    parse_json(data, tweet_ctr)
    tweet_ctr += 1
  #once the json is parsed, we need to run over the idf dict once more
  terms = idf.keys()
  n = len(tweets.keys())
  for k in terms:
    idf[k] = math.log(n/idf[k], 2)
  return

"""method that calculates tf-idf and normalizes them"""
def calculate_tfidf():
  tweet_ids = tf.keys()
  for twt_id in tweet_ids:
    terms = tf[twt_id].keys()
    sum_of_sq = 0
    for term in terms:
      tf[twt_id][term] *= idf[term]
      sum_of_sq += tf[twt_id][term]*tf[twt_id][term]
    #calculate the normalized values
    norm = math.sqrt(sum_of_sq)
    for term in terms:
      tf[twt_id][term] /= norm
  return

"""tweet ranker
def rank_tweets(query_struct):
  docs = tf.keys()
  top_ranked = []
  for doc in docs:
    print 'Ranking tweet {0}'.format(doc)
    tfidf_query = defaultdict(float)
    terms = tf[doc]
    sum_of_sq = 0.0
    for t in terms:
      val = 0.0
      print 'Term {0} in tweet {1}'.format(t.encode('utf-8'), doc)
      if(t in query_struct):
        print '\tTerm {0} also is in query'.format(t)
        val = query_struct[t]
        val = 1+math.log(val, 2)
      tfidf_query[t] = val*idf[t]
      sum_of_sq += tfidf_query[t]*tfidf_query[t]
    #now normalize the tf-idf weights of the query
    norm = math.sqrt(sum_of_sq)
    terms = tfidf_query.keys()
    #if the tweet is irrelevant, ignore it 
    if(norm == 0):
      s = 'Tweet {0}, score: 0'.format(doc)
      top_ranked.append(s)
      continue
    for t in terms:
      tfidf_query[t] /= norm
    #once normalized, we can calculate the cosine of query and doc
    cosine_sum = 0.0
    for t in terms:
      cosine_sum += tfidf_query[t]*tf[doc][t]
    s = 'Tweet {0}, score: {1}'.format(doc, cosine_sum)
    top_ranked.append(s)
    print tfidf_query
  print top_ranked
  return"""

"""tweet ranker"""
def rank_tweets(query_struct):
  docs = tf.keys()
  top_ranked = []
  #build the tf-idf dict for the query; this is constant for all tweets
  query_terms = query_struct.keys()
  sum_of_sq = 0
  valid_tweet = False
  for term in query_terms:
    if(term not in idf):
      print 'No match :('
      return
    val = query_struct[term]
    val = 1+math.log(val, 2)
    val *= idf[term]
    sum_of_sq += val*val
    query_struct[term] = val
  norm = math.sqrt(sum_of_sq)
  if(norm != 0):
    for term in query_terms:
      query_struct[term] /= norm
  
  #now iterate through all tweets computing their score
  for doc in docs:
    print 'Ranking tweet {0}'.format(doc)
    cosine_sum = 0.0
    terms = tf[doc]
    for t in terms:
      cosine_sum += query_struct[t]*tf[doc][t]
    insort(top_ranked, cosine_sum)
    #s = 'Tweet {0}, score: {1}'.format(doc, cosine_sum)
    #top_ranked.append(s)
  print_result(top_ranked)
  return

"""build the tf-idf system for the tweets"""
def process_tweets(filename):
  parse(filename)
  calculate_tfidf()
  print_concise()
  return

"""pre-process the query and then do the ranking of tweets"""
def process_query(query):
  q_str = defaultdict(float)
  tokens = tokenize(query)
  for token in tokens:
    q_str[token] += 1
  print 'Query: {0}'.format(q_str)
  rank_tweets(q_str)
  return

def print_concise():
  print 'No of tweets: {0}'.format(len(tweets))
  print 'Size of tf dict: {0}'.format(len(tf.keys()))
  print 'Size of idf dict: {0}'.format(len(idf.keys()))

def print_verbose():
  print 'tweets====='
  for k in tweets.keys():
    print '{0}: {1}'.format(k, tweets[k].encode('utf-8'))
  print '\ntf======'
  for k in tf.keys():
    print '\ntweet {0}'.format(k)
    for kprime in tf[k].keys():
      print '{0}: {1}'.format(kprime.encode('utf-8'), tf[k][kprime])
  print '\nidf======'
  for k in sorted(idf.keys()):
    print '{0}: {1}'.format(k.encode('utf-8'), idf[k])
  return   

def print_result(top_ranked):
  res = top_ranked[len(top_ranked)-50:]
  res.reverse()
  print '\nRankings=========='
  for r in res:
    print r
  return

def main():
  #signal.signal(signal.SIGINT, signal_handler)
  prompt = '>>'
  #n = len(sys.argv)
  #if(n != 2):
  #  print 'usage: python vector_space.py <input_json_file>'
  #  sys.exit(1)
  #dir_name = str(sys.argv[1])
  #filename  = 'b.json'
  filename = 'mars_tweets_medium.json'
  process_tweets(filename)
  process_query('mars rover')
  """while(True):
    print prompt,
    query = raw_input()
    if(query == ''):
      continue
    process_query(query)
    print"""
  return

if __name__ == '__main__':
  main()
